# Idee sul tema
- Il tema della run lo sceglie l'utente
- Al finale del gioco, si avrà un recap di tutte le scelte e della story line e gli utenti potranno votare alla fine la run più "bella"
	- Sarà l'ia a scrivere tutta la storia in base alle scelte fatte e alla dinamica della run che sara unica ogno volta. [[Idea finale crea storia]]
- Erice nome personaggio
- obsidian nome del gioco
- Stile delle carte diverso in base alla fazione o alla situazione
- 
